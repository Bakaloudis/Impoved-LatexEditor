package model.encryption;

public interface EncryptionStrategy {
	public String getEncryptedText(String text);
}
